--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

-- Started on 2022-12-21 10:08:47

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3500 (class 0 OID 17701)
-- Dependencies: 238
-- Data for Name: il; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.il ("ilNo", "ilAdi") VALUES (1, 'SAKARYA');


--
-- TOC entry 3502 (class 0 OID 17708)
-- Dependencies: 240
-- Data for Name: ilce; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ilce ("ilceNo", "ilceAdi", "ilNO") VALUES (1, 'SERDIVAN', 1);


--
-- TOC entry 3483 (class 0 OID 16806)
-- Dependencies: 221
-- Data for Name: kisi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kisi ("KNo", "kisiId", adi, soyadi, "Uye", "Personel") VALUES (76, 1212121, 'jamal', 'ALI', 'H', 'E');
INSERT INTO public.kisi ("KNo", "kisiId", adi, soyadi, "Uye", "Personel") VALUES (114, 4545, 'amir', 'AMIR', 'E', 'H');
INSERT INTO public.kisi ("KNo", "kisiId", adi, soyadi, "Uye", "Personel") VALUES (113, 645, 'saed', 'JAMAL', 'H', 'E');


--
-- TOC entry 3504 (class 0 OID 17720)
-- Dependencies: 242
-- Data for Name: mahalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.mahalle ("mahalleNo", "mahalleAdi", "ilceNo") VALUES (1, 'kemalpasa', 1);
INSERT INTO public.mahalle ("mahalleNo", "mahalleAdi", "ilceNo") VALUES (2, 'Arabac?alan?', 1);
INSERT INTO public.mahalle ("mahalleNo", "mahalleAdi", "ilceNo") VALUES (3, 'Kazimpasa', 1);


--
-- TOC entry 3506 (class 0 OID 17732)
-- Dependencies: 244
-- Data for Name: sokak; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sokak ("No", "mahalleNo") VALUES (2, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (3, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (4, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (5, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (6, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (7, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (8, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (9, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (10, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (11, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (12, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (13, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (14, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (15, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (16, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (17, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (18, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (19, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (20, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (21, 1);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (22, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (23, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (24, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (25, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (26, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (27, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (28, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (29, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (30, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (31, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (32, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (33, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (34, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (35, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (36, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (37, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (38, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (39, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (40, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (41, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (42, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (43, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (44, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (45, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (46, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (47, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (48, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (49, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (50, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (51, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (52, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (53, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (54, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (55, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (56, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (57, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (58, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (59, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (60, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (61, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (62, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (63, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (64, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (65, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (66, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (67, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (68, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (69, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (70, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (71, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (72, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (73, 3);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (74, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (75, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (76, 2);
INSERT INTO public.sokak ("No", "mahalleNo") VALUES (77, 2);


--
-- TOC entry 3477 (class 0 OID 16594)
-- Dependencies: 215
-- Data for Name: adres; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.adres ("adresNo", "ilNo", kisi_id, "ilceNo", "mahalleNo", "sokakNo") VALUES (58, 1, 113, 1, 1, 2);
INSERT INTO public.adres ("adresNo", "ilNo", kisi_id, "ilceNo", "mahalleNo", "sokakNo") VALUES (59, 1, 114, 1, 1, 2);
INSERT INTO public.adres ("adresNo", "ilNo", kisi_id, "ilceNo", "mahalleNo", "sokakNo") VALUES (34, 1, 76, 1, 1, 10);


--
-- TOC entry 3479 (class 0 OID 16606)
-- Dependencies: 217
-- Data for Name: yayinevi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.yayinevi ("No", adi) VALUES (1, 'BEYAZEV');


--
-- TOC entry 3481 (class 0 OID 16618)
-- Dependencies: 219
-- Data for Name: yazar; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.yazar ("No", "Adi", yas) VALUES (1, 'ALI', 55);
INSERT INTO public.yazar ("No", "Adi", yas) VALUES (2, 'CEMIL', 35);


--
-- TOC entry 3491 (class 0 OID 16867)
-- Dependencies: 229
-- Data for Name: kitap; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (1, 'ELMA', 1, 1, 'KOMIK', 5, 0);
INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (5, 'VTYS', 1, 1, 'BMG', 5, 0);
INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (6, 'matematik', 1, 1, 'bilimsel', 5, 0);
INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (7, 'VERIYAPILARI', 1, 1, 'bilemsel', 5, 0);
INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (4, 'ASK', 1, 1, 'ROMANTIK', 5, 0);
INSERT INTO public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") VALUES (9, 'kimya', 1, 1, 'bilemsel', 5, 0);


--
-- TOC entry 3484 (class 0 OID 16814)
-- Dependencies: 222
-- Data for Name: personel; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.personel ("PNo", "Ucreti") VALUES (76, 5000);
INSERT INTO public.personel ("PNo", "Ucreti") VALUES (113, 5000);


--
-- TOC entry 3485 (class 0 OID 16819)
-- Dependencies: 223
-- Data for Name: uye; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.uye ("UNo", "Kayittarihi", "OD_Al_kit_S") VALUES (114, '2022-12-16', 0);


--
-- TOC entry 3496 (class 0 OID 16907)
-- Dependencies: 234
-- Data for Name: odunc; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3489 (class 0 OID 16859)
-- Dependencies: 227
-- Data for Name: fatura; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3487 (class 0 OID 16842)
-- Dependencies: 225
-- Data for Name: ilet_b; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.ilet_b ("iletNO", "TelNO", adresid, "kisiId", "EmailAD") VALUES (34, 2153435, 34, 76, 'J@GMAIL.COM');
INSERT INTO public.ilet_b ("iletNO", "TelNO", adresid, "kisiId", "EmailAD") VALUES (53, 153454, 58, 113, '');
INSERT INTO public.ilet_b ("iletNO", "TelNO", adresid, "kisiId", "EmailAD") VALUES (54, 44545, 59, 114, '');


--
-- TOC entry 3494 (class 0 OID 16876)
-- Dependencies: 232
-- Data for Name: kit_ad; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kit_ad ("KOD", "KAT", kit_id, raf) VALUES (1, 1, 1, 1);


--
-- TOC entry 3498 (class 0 OID 17052)
-- Dependencies: 236
-- Data for Name: kutuphane; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.kutuphane ("NO", adi, "SorumluId", "Uye_Sayisi", "kitap_Sayisi", "Personel_Sayisi") VALUES (2, 'MARKEZI KUTUPHANE', 76, 1, 6, 2);


--
-- TOC entry 3508 (class 0 OID 17781)
-- Dependencies: 246
-- Data for Name: sil_kisi; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (1, 2, 1212, 'jamal', 'ALI', 'Uye', '2022-12-15');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (2, 2, 1212, 'jamal', 'ALI', 'Uye', '2022-12-15');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (6, 2, 12354, 'amera', 'ALI', 'Uye', '2022-12-15');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (7, 2, 12354444, 'amer', 'BASEET', 'Uye', '2022-12-15');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (8, 2, 154451, 'amir', 'BASEET', 'Uye', '2022-12-15');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (9, 2, 12354, 'amera', 'ALI', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (10, 2, 11111, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (11, 2, 55645, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (12, 2, 1545687, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (13, 2, 15478, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (14, 2, 1023544, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (15, 2, 1546564, 'eid', 'JAMAL', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (16, 2, 15456878, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (18, 2, 564645, 'amira', 'MOHMAMAD', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (19, 2, 12313212, 'samer', 'SAED', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (20, 2, 16456, 'samera', 'EID', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (21, 2, 1645648, 'sami', 'EID', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (22, 2, 1215, 'abdulrahman', 'ALI', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (23, 2, 1212, 'jamal', 'ALI', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (24, 2, 1235465, 'alaa', 'MASRI', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (25, 2, 65465, 'ali', 'YAMAN', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (26, 2, 4545, 'amir', 'AMIR', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (27, 2, 645, 'ali', 'ALI', 'Uye', '2022-12-16');
INSERT INTO public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") VALUES (28, 2, 45645, 'issa', 'ALI', 'Uye', '2022-12-17');


--
-- TOC entry 3514 (class 0 OID 0)
-- Dependencies: 214
-- Name: adres_adresNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."adres_adresNo_seq"', 60, true);


--
-- TOC entry 3515 (class 0 OID 0)
-- Dependencies: 226
-- Name: fatura_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."fatura_NO_seq"', 30, true);


--
-- TOC entry 3516 (class 0 OID 0)
-- Dependencies: 237
-- Name: il_ilNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."il_ilNo_seq"', 1, true);


--
-- TOC entry 3517 (class 0 OID 0)
-- Dependencies: 239
-- Name: ilce_ilceNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ilce_ilceNo_seq"', 3, true);


--
-- TOC entry 3518 (class 0 OID 0)
-- Dependencies: 224
-- Name: ilet_b_iletNO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ilet_b_iletNO_seq"', 55, true);


--
-- TOC entry 3519 (class 0 OID 0)
-- Dependencies: 220
-- Name: kisi_KNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kisi_KNo_seq"', 115, true);


--
-- TOC entry 3520 (class 0 OID 0)
-- Dependencies: 230
-- Name: kit_ad_KOD_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kit_ad_KOD_seq"', 1, true);


--
-- TOC entry 3521 (class 0 OID 0)
-- Dependencies: 231
-- Name: kit_ad_raf_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kit_ad_raf_seq', 1, true);


--
-- TOC entry 3522 (class 0 OID 0)
-- Dependencies: 228
-- Name: kitap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitap_id_seq', 9, true);


--
-- TOC entry 3523 (class 0 OID 0)
-- Dependencies: 235
-- Name: kutuphane_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kutuphane_NO_seq"', 2, true);


--
-- TOC entry 3524 (class 0 OID 0)
-- Dependencies: 241
-- Name: mahalle_mahalleNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."mahalle_mahalleNo_seq"', 3, true);


--
-- TOC entry 3525 (class 0 OID 0)
-- Dependencies: 233
-- Name: odunc_islemNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."odunc_islemNo_seq"', 33, true);


--
-- TOC entry 3526 (class 0 OID 0)
-- Dependencies: 245
-- Name: sil_kisi_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."sil_kisi_NO_seq"', 28, true);


--
-- TOC entry 3527 (class 0 OID 0)
-- Dependencies: 243
-- Name: sokak_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."sokak_No_seq"', 77, true);


--
-- TOC entry 3528 (class 0 OID 0)
-- Dependencies: 216
-- Name: yayinevi_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."yayinevi_No_seq"', 1, true);


--
-- TOC entry 3529 (class 0 OID 0)
-- Dependencies: 218
-- Name: yazar_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."yazar_No_seq"', 2, true);


-- Completed on 2022-12-21 10:08:47

--
-- PostgreSQL database dump complete
--

