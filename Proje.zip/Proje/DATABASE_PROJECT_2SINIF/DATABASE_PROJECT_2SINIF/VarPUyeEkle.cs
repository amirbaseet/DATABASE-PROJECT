﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class VarPUyeEkle : Form
    {
        public VarPUyeEkle()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();

            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView1.AutoResizeColumns();
            this.dataGridView1.AutoSize = true;
        }

        private void VarPUyeEkle_Load(object sender, EventArgs e)
        {
            Select();
        }
      

        private void button1_Click(object sender, EventArgs e)
        {
            Global.Var_UYE_Ekel(int.Parse(kisiID.Text));
            Select();
        }
        private void Select()
        {
            string command = "select * from kisi RIGHT JOIN Personel ON kisi.\"KNo\" =Personel.\"PNo\" where kisi.\"Uye\"='H'";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(command, Global.connection);

            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];


        }
    }
}
