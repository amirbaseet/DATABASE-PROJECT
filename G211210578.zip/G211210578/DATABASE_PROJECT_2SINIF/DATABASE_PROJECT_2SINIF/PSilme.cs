﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class PSilme : Form
    {
        public PSilme()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Global.P_Sil(int.Parse(kisiID.Text));
        }
    }
}
