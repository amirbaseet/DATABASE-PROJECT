﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace DATABASE_PROJECT_2SINIF
{
    public static class Global
    {
        public static NpgsqlConnection connection = new NpgsqlConnection("server =localhost;port = 2002;Database=kutuphane;user ID=postgres; password =zxc123");

        public static void Postgresql(string sql)
        {
            if (connection.State != ConnectionState.Open)
            {
                connection.Open();
            }

            string command = sql;
            NpgsqlCommand command1 = new NpgsqlCommand(command, connection);

            command1.ExecuteNonQuery();
            connection.Close();
        }
        public static void kisiSil() 
        {
            string command = "delete from kisi where \"Uye\"='H' and \"Personel\"='H'";
            Postgresql(command);
        }
        public static void Y_Per_ekle(int id, string adi, string soyadi, int Ucreti, int il, int ilce, 
                                                            int mahalle, int sokak, int tel, string Email)
        {
           
            string command = $"CALL add_Personel({id},'{adi}','{soyadi}',{Ucreti},{il}" +
                                              $",{ilce},{mahalle}," +
                                              $"{sokak},{tel},'{Email}')";
            Postgresql(command);
        }
        public static void V_P_Ekel(int id,int Ucreti) 
        {
           

            string command = $"CALL ADD_P_if_k_exst({id},{Ucreti})";


            Postgresql(command);
        } 
        
        public static void P_Sil(int id) 
        {
          

            string command = $"CALL delete_Personel({id})";

            Postgresql(command);
            kisiSil();

        }
        public static void Yeni_UYe_ekle(int id, string adi, string soyadi, int il, int ilce, int mahalle, int sokak, int tel, string Email)
        {
            string command = $"CALL add_Uye({id},'{adi}','{soyadi}',{il}" +
                                              $",{ilce},{mahalle}," +
                                              $"{sokak},{tel},'{Email}')";

            Postgresql(command);
        }
        public static void Var_UYE_Ekel(int id) 
        {
            string command = $"CALL ADD_Uye_if_k_exst({id})";

            Postgresql(command);
        }

        public static void U_Sil(int id) 
        {
           

            string command = $"CALL delete_Uye({id})";

            Postgresql(command);
            kisiSil();


        }
        public static void KtpEkle(string KtpAdi, int YazarID, int YayinevID, string tur, int stockSayisi)
        {
           

            string command = $"INSERT INTO kitap(\"adi\",\"yazarid\",\"yayinevi_ID\",\"tur\",\"stockSayisi\")" +
                             $"VALUES('{KtpAdi}',{YazarID},{YayinevID},'{tur}',{stockSayisi})";
            Postgresql(command);

           
        }
        public static void OduncVer(int UyeId,int PersonelId,int KtpId) 
        {
            string command = $"CALL ODUNC({UyeId},{PersonelId},{KtpId})";
            Postgresql(command);
        }
        public static void KitapIade(int UyeId,int PersonelId,int KtpId) 
        {
            string command = $"CALL IADE({UyeId},{PersonelId},{KtpId})";
            Postgresql(command);
        }

    }
   

}

