﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class UyeEklecs : Form
    {
        public UyeEklecs()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Global.Yeni_UYe_ekle(int.Parse(kisiID.Text), adi.Text, soyadi.Text, int.Parse(il.Text), int.Parse(ilce.Text),
                int.Parse(mahalle.Text), int.Parse(sokak.Text), int.Parse(tel.Text), EmailAD.Text);
        }
}
}
