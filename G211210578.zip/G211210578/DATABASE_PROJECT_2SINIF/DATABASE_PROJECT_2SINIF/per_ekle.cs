﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class per_ekle : Form
    {
        public per_ekle()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            yeniPer_ekle yeniPer_Ekle=new yeniPer_ekle();
            yeniPer_Ekle.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VarPEkle varPEkle = new VarPEkle();
            varPEkle.ShowDialog();
        }
    }
}
