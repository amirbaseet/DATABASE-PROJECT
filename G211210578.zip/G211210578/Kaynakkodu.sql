--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

-- Started on 2022-12-20 16:00:17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 269 (class 1255 OID 17654)
-- Name: add_p_if_k_exst(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_p_if_k_exst(IN _kisiid integer, IN _ucreti integer)
    LANGUAGE sql
    AS $$
UPDATE kisi SET "Personel"='E';
INSERT INTO personel("PNo","Ucreti")
VALUES (KNo_getir( _kisiId ),_Ucreti);


$$;


ALTER PROCEDURE public.add_p_if_k_exst(IN _kisiid integer, IN _ucreti integer) OWNER TO postgres;

--
-- TOC entry 268 (class 1255 OID 17472)
-- Name: add_personel(integer, character varying, character varying, integer, integer, integer, integer, integer, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_personel(IN _kisiid integer, IN _adi character varying, IN _soyadi character varying, IN _ucreti integer, IN _ilno integer, IN _ilceno integer, IN _mahalleno integer, IN _sokakno integer, IN _telno integer, IN _emailad character varying)
    LANGUAGE sql
    AS $$
INSERT INTO kisi("kisiId","adi","soyadi","Uye","Personel")
Values( _kisiId ,_adi ,_soyadi , 'H', 'E');
INSERT INTO personel("PNo","Ucreti")
VALUES (currval('"kisi_KNo_seq"'),_Ucreti);

INSERT INTO adres ("ilNo","ilceNo","mahalleNo","sokakNo","kisi_id")
VALUES(_ilNo,_ilceNo,_mahalleNo,_sokakNo,currval('"kisi_KNo_seq"'));

INSERT INTO ilet_b("TelNO","adresid","kisiId","EmailAD")
VALUES(_TelNO,currval('"adres_adresNo_seq"'),currval('"kisi_KNo_seq"'),_EmailAD);

$$;


ALTER PROCEDURE public.add_personel(IN _kisiid integer, IN _adi character varying, IN _soyadi character varying, IN _ucreti integer, IN _ilno integer, IN _ilceno integer, IN _mahalleno integer, IN _sokakno integer, IN _telno integer, IN _emailad character varying) OWNER TO postgres;

--
-- TOC entry 272 (class 1255 OID 17659)
-- Name: add_uye(integer, character varying, character varying, integer, integer, integer, integer, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_uye(IN _kisiid integer, IN _adi character varying, IN _soyadi character varying, IN _ilno integer, IN _ilceno integer, IN _mahalleno integer, IN _sokakno integer, IN _telno integer, IN _emailad character varying)
    LANGUAGE sql
    AS $$
INSERT INTO kisi("kisiId","adi","soyadi","Uye","Personel")
Values( _kisiId ,_adi ,_soyadi , 'E', 'H');

INSERT INTO Uye("UNo")
VALUES (currval('"kisi_KNo_seq"'));

INSERT INTO adres ("ilNo","ilceNo","mahalleNo","sokakNo","kisi_id")
VALUES(_ilNo,_ilceNo,_mahalleNo,_sokakNo,currval('"kisi_KNo_seq"'));

INSERT INTO ilet_b("TelNO","adresid","kisiId","EmailAD")
VALUES(_TelNO,currval('"adres_adresNo_seq"'),currval('"kisi_KNo_seq"'),_EmailAD);

$$;


ALTER PROCEDURE public.add_uye(IN _kisiid integer, IN _adi character varying, IN _soyadi character varying, IN _ilno integer, IN _ilceno integer, IN _mahalleno integer, IN _sokakno integer, IN _telno integer, IN _emailad character varying) OWNER TO postgres;

--
-- TOC entry 276 (class 1255 OID 17660)
-- Name: add_uye_if_k_exst(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_uye_if_k_exst(IN _kisiid integer)
    LANGUAGE sql
    AS $$
UPDATE kisi SET "Uye"='E' WHERE "KNo"=KNo_getir( _kisiId );
INSERT INTO Uye("UNo")
VALUES (KNo_getir( _kisiId ));


$$;


ALTER PROCEDURE public.add_uye_if_k_exst(IN _kisiid integer) OWNER TO postgres;

--
-- TOC entry 266 (class 1255 OID 17572)
-- Name: adi_getir(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.adi_getir(_kisiid integer) RETURNS character varying
    LANGUAGE sql
    AS $$
    SELECT  "adi" from kisi WHERE "KNo"=_kisiId;
$$;


ALTER FUNCTION public.adi_getir(_kisiid integer) OWNER TO postgres;

--
-- TOC entry 275 (class 1255 OID 17668)
-- Name: delete_personel(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_personel(IN _kno integer)
    LANGUAGE sql
    AS $$
   DELETE FROM Personel WHERE "PNo"=KNo_getir( _KNO);
   UPDATE kisi set "Personel" = 'H' WHERE "KNo" =KNo_getir( _KNO);
   UPDATE kutuphane set "Personel_Sayisi" = "Personel_Sayisi"-1 where "NO" = 2;
$$;


ALTER PROCEDURE public.delete_personel(IN _kno integer) OWNER TO postgres;

--
-- TOC entry 274 (class 1255 OID 17670)
-- Name: delete_uye(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_uye(IN _kno integer)
    LANGUAGE sql
    AS $$
   DELETE FROM Uye WHERE "UNo"= KNo_getir( _KNO);
   UPDATE kisi set "Uye" = 'H' WHERE "KNo" =KNo_getir( _KNO);
   UPDATE kutuphane set "Uye_Sayisi" = "Uye_Sayisi"-1 where "NO" = 2;
$$;


ALTER PROCEDURE public.delete_uye(IN _kno integer) OWNER TO postgres;

--
-- TOC entry 261 (class 1255 OID 17422)
-- Name: iade(integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.iade(IN _uyeid integer, IN _personelid integer, IN _kitap_id integer)
    LANGUAGE sql
    AS $$

INSERT INTO Odunc("UyeId","PersonelID","OD_Al_kit_ID","Tur")
VALUES(KNo_getir(_UyeId),KNo_getir(_PersonelID),_KITAP_id ,'IADE');

 INSERT INTO fatura("Topalm","islemNo")
VALUES(0,currval('"odunc_islemNo_seq"'));

UPDATE kitap set "O_AL_S"= "O_AL_S"-1 WHERE "id"=_KITAP_id;

 UPDATE Uye SET "OD_Al_kit_S" = "OD_Al_kit_S"-1 WHERE "UNo"=KNo_getir(_UyeId);

$$;


ALTER PROCEDURE public.iade(IN _uyeid integer, IN _personelid integer, IN _kitap_id integer) OWNER TO postgres;

--
-- TOC entry 265 (class 1255 OID 17571)
-- Name: kisiid_getir(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kisiid_getir(_kisiid integer) RETURNS integer
    LANGUAGE sql
    AS $$
    SELECT  "kisiId" from kisi WHERE "KNo"=_kisiId;
$$;


ALTER FUNCTION public.kisiid_getir(_kisiid integer) OWNER TO postgres;

--
-- TOC entry 273 (class 1255 OID 17632)
-- Name: kno_getir(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.kno_getir(_kisiid integer) RETURNS integer
    LANGUAGE sql
    AS $$
    SELECT  "KNo" from kisi WHERE "kisiId"=_kisiId;
$$;


ALTER FUNCTION public.kno_getir(_kisiid integer) OWNER TO postgres;

--
-- TOC entry 247 (class 1255 OID 17469)
-- Name: ktp_ekl(character varying, integer, integer, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.ktp_ekl(IN _adi character varying, IN _yazarid integer, IN _yayinevi_id integer, IN _tur character varying, IN _stocksayisi integer)
    LANGUAGE sql
    AS $$
insert into kitap("adi","yazarid","yayinevi_ID","tur","stockSayisi")
VALUES(_adi,_yazarid,_yayinevi_ID,_tur,_stockSayisi);

 INSERT INTO kit_ad("kit_id") VALUES(currval('"kitap_id_seq"'));
$$;


ALTER PROCEDURE public.ktp_ekl(IN _adi character varying, IN _yazarid integer, IN _yayinevi_id integer, IN _tur character varying, IN _stocksayisi integer) OWNER TO postgres;

--
-- TOC entry 271 (class 1255 OID 17657)
-- Name: ktp_s_arttr(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ktp_s_arttr() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
UPDATE kutuphane SET "kitap_Sayisi"= "kitap_Sayisi"+1 where "NO"=2;
RETURN OLD;

END;
$$;


ALTER FUNCTION public.ktp_s_arttr() OWNER TO postgres;

--
-- TOC entry 262 (class 1255 OID 17421)
-- Name: odunc(integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.odunc(IN _uyeid integer, IN _personelid integer, IN _kitap_id integer)
    LANGUAGE sql
    AS $$

INSERT INTO Odunc("UyeId","PersonelID","OD_Al_kit_ID","Tur")
VALUES(KNo_getir(_UyeId),KNo_getir(_PersonelID),_KITAP_id,'ODUNC AL');

 INSERT INTO fatura("Topalm","islemNo")
VALUES(10,currval('"odunc_islemNo_seq"'));

UPDATE kitap set "O_AL_S"= "O_AL_S"+1 WHERE "id"=_KITAP_id;

 UPDATE Uye SET "OD_Al_kit_S" = "OD_Al_kit_S"+1 WHERE "UNo"=KNo_getir(_UyeId);

$$;


ALTER PROCEDURE public.odunc(IN _uyeid integer, IN _personelid integer, IN _kitap_id integer) OWNER TO postgres;

--
-- TOC entry 263 (class 1255 OID 17525)
-- Name: personel_s_arttr(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.personel_s_arttr() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE eski INT;
BEGIN
eski ="Personel_Sayisi" from kutuphane  WHERE "NO"=2;
eski = eski +1;
UPDATE kutuphane SET  "Personel_Sayisi"= eski  WHERE "NO"=2;

   return OLD;
END;
$$;


ALTER FUNCTION public.personel_s_arttr() OWNER TO postgres;

--
-- TOC entry 270 (class 1255 OID 17661)
-- Name: personel_sil_once(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.personel_sil_once() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE 
      id INT;
      adi VARCHAR(255);
      Soyadi VARCHAR(255);
     
         BEGIN
         id = kisiId_getir(OLD."PNo");
         adi = adi_getir(OLD."PNo");
         Soyadi =Soyadi_getir(OLD."PNo");
         

          INSERT INTO sil_kisi("id","adi","Soyadi","tur" ,"kutuphaneid") 
            VALUES (id,adi,Soyadi,'Uye',2);

            return OLD;
         
           
         END;
      $$;


ALTER FUNCTION public.personel_sil_once() OWNER TO postgres;

--
-- TOC entry 267 (class 1255 OID 17573)
-- Name: soyadi_getir(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.soyadi_getir(_kisiid integer) RETURNS character varying
    LANGUAGE sql
    AS $$
    SELECT  "soyadi" from kisi WHERE "KNo"=_kisiId;
$$;


ALTER FUNCTION public.soyadi_getir(_kisiid integer) OWNER TO postgres;

--
-- TOC entry 264 (class 1255 OID 17531)
-- Name: uye_s_arttr(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.uye_s_arttr() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE eski INT;
BEGIN
eski ="Uye_Sayisi" from kutuphane  WHERE "NO"=2;
eski = eski +1;
UPDATE kutuphane SET  "Uye_Sayisi"= eski  WHERE "NO"=2;
   return OLD;

END;
$$;


ALTER FUNCTION public.uye_s_arttr() OWNER TO postgres;

--
-- TOC entry 248 (class 1255 OID 17688)
-- Name: uye_sil_once(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.uye_sil_once() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
      DECLARE 
      id INT;
      adi VARCHAR(255);
      Soyadi VARCHAR(255);
     
         BEGIN
         id = kisiId_getir(OLD."UNo");
         adi = adi_getir(OLD."UNo");
         Soyadi =Soyadi_getir(OLD."UNo");
         

          INSERT INTO sil_kisi("id","adi","Soyadi","tur" ,"kutuphaneid") 
            VALUES (id,adi,Soyadi,'Uye',2);

            return OLD;
         
           
         END;
      $$;


ALTER FUNCTION public.uye_sil_once() OWNER TO postgres;

--
-- TOC entry 249 (class 1255 OID 17692)
-- Name: yazi_dzlt(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.yazi_dzlt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
NEW."adi"=LOWER(NEW."adi");
NEW."soyadi"=UPPER(NEW."soyadi");

RETURN NEW;
END;
$$;


ALTER FUNCTION public.yazi_dzlt() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 16594)
-- Name: adres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adres (
    "adresNo" integer NOT NULL,
    "ilNo" integer,
    kisi_id integer NOT NULL,
    "ilceNo" integer,
    "mahalleNo" integer,
    "sokakNo" integer
);


ALTER TABLE public.adres OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 16593)
-- Name: adres_adresNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."adres_adresNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."adres_adresNo_seq" OWNER TO postgres;

--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 214
-- Name: adres_adresNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."adres_adresNo_seq" OWNED BY public.adres."adresNo";


--
-- TOC entry 227 (class 1259 OID 16859)
-- Name: fatura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fatura (
    "NO" integer NOT NULL,
    "FaturaTarihi" date DEFAULT CURRENT_DATE,
    "Topalm" integer,
    "islemNo" integer NOT NULL
);


ALTER TABLE public.fatura OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16858)
-- Name: fatura_NO_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."fatura_NO_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."fatura_NO_seq" OWNER TO postgres;

--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 226
-- Name: fatura_NO_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."fatura_NO_seq" OWNED BY public.fatura."NO";


--
-- TOC entry 238 (class 1259 OID 17701)
-- Name: il; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.il (
    "ilNo" integer NOT NULL,
    "ilAdi" character varying(255)
);


ALTER TABLE public.il OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 17700)
-- Name: il_ilNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."il_ilNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."il_ilNo_seq" OWNER TO postgres;

--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 237
-- Name: il_ilNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."il_ilNo_seq" OWNED BY public.il."ilNo";


--
-- TOC entry 240 (class 1259 OID 17708)
-- Name: ilce; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ilce (
    "ilceNo" integer NOT NULL,
    "ilceAdi" character varying(255),
    "ilNO" integer
);


ALTER TABLE public.ilce OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 17707)
-- Name: ilce_ilceNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ilce_ilceNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ilce_ilceNo_seq" OWNER TO postgres;

--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 239
-- Name: ilce_ilceNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ilce_ilceNo_seq" OWNED BY public.ilce."ilceNo";


--
-- TOC entry 225 (class 1259 OID 16842)
-- Name: ilet_b; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ilet_b (
    "iletNO" integer NOT NULL,
    "TelNO" integer,
    adresid integer,
    "kisiId" integer,
    "EmailAD" character varying(255)
);


ALTER TABLE public.ilet_b OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16841)
-- Name: ilet_b_iletNO_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ilet_b_iletNO_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ilet_b_iletNO_seq" OWNER TO postgres;

--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 224
-- Name: ilet_b_iletNO_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ilet_b_iletNO_seq" OWNED BY public.ilet_b."iletNO";


--
-- TOC entry 221 (class 1259 OID 16806)
-- Name: kisi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kisi (
    "KNo" integer NOT NULL,
    "kisiId" integer,
    adi character varying(40) NOT NULL,
    soyadi character varying(40) NOT NULL,
    "Uye" character(1),
    "Personel" character(1)
);


ALTER TABLE public.kisi OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16805)
-- Name: kisi_KNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."kisi_KNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."kisi_KNo_seq" OWNER TO postgres;

--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 220
-- Name: kisi_KNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."kisi_KNo_seq" OWNED BY public.kisi."KNo";


--
-- TOC entry 232 (class 1259 OID 16876)
-- Name: kit_ad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kit_ad (
    "KOD" integer NOT NULL,
    "KAT" integer DEFAULT 1,
    kit_id integer,
    raf integer NOT NULL
);


ALTER TABLE public.kit_ad OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16874)
-- Name: kit_ad_KOD_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."kit_ad_KOD_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."kit_ad_KOD_seq" OWNER TO postgres;

--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 230
-- Name: kit_ad_KOD_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."kit_ad_KOD_seq" OWNED BY public.kit_ad."KOD";


--
-- TOC entry 231 (class 1259 OID 16875)
-- Name: kit_ad_raf_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kit_ad_raf_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kit_ad_raf_seq OWNER TO postgres;

--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 231
-- Name: kit_ad_raf_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kit_ad_raf_seq OWNED BY public.kit_ad.raf;


--
-- TOC entry 229 (class 1259 OID 16867)
-- Name: kitap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitap (
    id integer NOT NULL,
    adi character varying(255) NOT NULL,
    yazarid integer NOT NULL,
    "yayinevi_ID" integer NOT NULL,
    tur character varying(255),
    "stockSayisi" integer NOT NULL,
    "O_AL_S" integer DEFAULT 0
);


ALTER TABLE public.kitap OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16866)
-- Name: kitap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitap_id_seq OWNER TO postgres;

--
-- TOC entry 3547 (class 0 OID 0)
-- Dependencies: 228
-- Name: kitap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitap_id_seq OWNED BY public.kitap.id;


--
-- TOC entry 236 (class 1259 OID 17052)
-- Name: kutuphane; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kutuphane (
    "NO" integer NOT NULL,
    adi character varying(255),
    "SorumluId" integer NOT NULL,
    "Uye_Sayisi" integer DEFAULT 0 NOT NULL,
    "kitap_Sayisi" integer DEFAULT 0 NOT NULL,
    "Personel_Sayisi" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.kutuphane OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 17051)
-- Name: kutuphane_NO_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."kutuphane_NO_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."kutuphane_NO_seq" OWNER TO postgres;

--
-- TOC entry 3548 (class 0 OID 0)
-- Dependencies: 235
-- Name: kutuphane_NO_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."kutuphane_NO_seq" OWNED BY public.kutuphane."NO";


--
-- TOC entry 242 (class 1259 OID 17720)
-- Name: mahalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mahalle (
    "mahalleNo" integer NOT NULL,
    "mahalleAdi" character varying(255),
    "ilceNo" integer
);


ALTER TABLE public.mahalle OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 17719)
-- Name: mahalle_mahalleNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."mahalle_mahalleNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."mahalle_mahalleNo_seq" OWNER TO postgres;

--
-- TOC entry 3549 (class 0 OID 0)
-- Dependencies: 241
-- Name: mahalle_mahalleNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."mahalle_mahalleNo_seq" OWNED BY public.mahalle."mahalleNo";


--
-- TOC entry 234 (class 1259 OID 16907)
-- Name: odunc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.odunc (
    "islemNo" integer NOT NULL,
    "UyeId" integer NOT NULL,
    "OD_Al_kit_ID" integer NOT NULL,
    "Tur" character varying(10),
    "PersonelID" integer
);


ALTER TABLE public.odunc OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 16906)
-- Name: odunc_islemNo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."odunc_islemNo_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."odunc_islemNo_seq" OWNER TO postgres;

--
-- TOC entry 3550 (class 0 OID 0)
-- Dependencies: 233
-- Name: odunc_islemNo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."odunc_islemNo_seq" OWNED BY public.odunc."islemNo";


--
-- TOC entry 222 (class 1259 OID 16814)
-- Name: personel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personel (
    "PNo" integer NOT NULL,
    "Ucreti" integer NOT NULL
);


ALTER TABLE public.personel OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 17781)
-- Name: sil_kisi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sil_kisi (
    "NO" integer NOT NULL,
    kutuphaneid integer NOT NULL,
    id integer NOT NULL,
    adi character varying(255),
    "Soyadi" character varying(255),
    tur character varying(255),
    "SilmeTarihi" date DEFAULT CURRENT_DATE
);


ALTER TABLE public.sil_kisi OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 17780)
-- Name: sil_kisi_NO_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."sil_kisi_NO_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."sil_kisi_NO_seq" OWNER TO postgres;

--
-- TOC entry 3551 (class 0 OID 0)
-- Dependencies: 245
-- Name: sil_kisi_NO_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."sil_kisi_NO_seq" OWNED BY public.sil_kisi."NO";


--
-- TOC entry 244 (class 1259 OID 17732)
-- Name: sokak; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sokak (
    "No" integer NOT NULL,
    "mahalleNo" integer
);


ALTER TABLE public.sokak OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 17731)
-- Name: sokak_No_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."sokak_No_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."sokak_No_seq" OWNER TO postgres;

--
-- TOC entry 3552 (class 0 OID 0)
-- Dependencies: 243
-- Name: sokak_No_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."sokak_No_seq" OWNED BY public.sokak."No";


--
-- TOC entry 223 (class 1259 OID 16819)
-- Name: uye; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uye (
    "UNo" integer NOT NULL,
    "Kayittarihi" date DEFAULT CURRENT_DATE,
    "OD_Al_kit_S" integer DEFAULT 0
);


ALTER TABLE public.uye OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16606)
-- Name: yayinevi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yayinevi (
    "No" integer NOT NULL,
    adi character varying(255)
);


ALTER TABLE public.yayinevi OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16605)
-- Name: yayinevi_No_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."yayinevi_No_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."yayinevi_No_seq" OWNER TO postgres;

--
-- TOC entry 3553 (class 0 OID 0)
-- Dependencies: 216
-- Name: yayinevi_No_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."yayinevi_No_seq" OWNED BY public.yayinevi."No";


--
-- TOC entry 219 (class 1259 OID 16618)
-- Name: yazar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yazar (
    "No" integer NOT NULL,
    "Adi" character varying(20),
    yas integer
);


ALTER TABLE public.yazar OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16617)
-- Name: yazar_No_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."yazar_No_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."yazar_No_seq" OWNER TO postgres;

--
-- TOC entry 3554 (class 0 OID 0)
-- Dependencies: 218
-- Name: yazar_No_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."yazar_No_seq" OWNED BY public.yazar."No";


--
-- TOC entry 3271 (class 2604 OID 16597)
-- Name: adres adresNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres ALTER COLUMN "adresNo" SET DEFAULT nextval('public."adres_adresNo_seq"'::regclass);


--
-- TOC entry 3278 (class 2604 OID 16862)
-- Name: fatura NO; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fatura ALTER COLUMN "NO" SET DEFAULT nextval('public."fatura_NO_seq"'::regclass);


--
-- TOC entry 3290 (class 2604 OID 17704)
-- Name: il ilNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.il ALTER COLUMN "ilNo" SET DEFAULT nextval('public."il_ilNo_seq"'::regclass);


--
-- TOC entry 3291 (class 2604 OID 17711)
-- Name: ilce ilceNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilce ALTER COLUMN "ilceNo" SET DEFAULT nextval('public."ilce_ilceNo_seq"'::regclass);


--
-- TOC entry 3277 (class 2604 OID 16845)
-- Name: ilet_b iletNO; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilet_b ALTER COLUMN "iletNO" SET DEFAULT nextval('public."ilet_b_iletNO_seq"'::regclass);


--
-- TOC entry 3274 (class 2604 OID 16809)
-- Name: kisi KNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi ALTER COLUMN "KNo" SET DEFAULT nextval('public."kisi_KNo_seq"'::regclass);


--
-- TOC entry 3282 (class 2604 OID 16879)
-- Name: kit_ad KOD; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kit_ad ALTER COLUMN "KOD" SET DEFAULT nextval('public."kit_ad_KOD_seq"'::regclass);


--
-- TOC entry 3284 (class 2604 OID 16881)
-- Name: kit_ad raf; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kit_ad ALTER COLUMN raf SET DEFAULT nextval('public.kit_ad_raf_seq'::regclass);


--
-- TOC entry 3280 (class 2604 OID 16870)
-- Name: kitap id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap ALTER COLUMN id SET DEFAULT nextval('public.kitap_id_seq'::regclass);


--
-- TOC entry 3286 (class 2604 OID 17055)
-- Name: kutuphane NO; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kutuphane ALTER COLUMN "NO" SET DEFAULT nextval('public."kutuphane_NO_seq"'::regclass);


--
-- TOC entry 3292 (class 2604 OID 17723)
-- Name: mahalle mahalleNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mahalle ALTER COLUMN "mahalleNo" SET DEFAULT nextval('public."mahalle_mahalleNo_seq"'::regclass);


--
-- TOC entry 3285 (class 2604 OID 16910)
-- Name: odunc islemNo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc ALTER COLUMN "islemNo" SET DEFAULT nextval('public."odunc_islemNo_seq"'::regclass);


--
-- TOC entry 3294 (class 2604 OID 17784)
-- Name: sil_kisi NO; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sil_kisi ALTER COLUMN "NO" SET DEFAULT nextval('public."sil_kisi_NO_seq"'::regclass);


--
-- TOC entry 3293 (class 2604 OID 17735)
-- Name: sokak No; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sokak ALTER COLUMN "No" SET DEFAULT nextval('public."sokak_No_seq"'::regclass);


--
-- TOC entry 3272 (class 2604 OID 16609)
-- Name: yayinevi No; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yayinevi ALTER COLUMN "No" SET DEFAULT nextval('public."yayinevi_No_seq"'::regclass);


--
-- TOC entry 3273 (class 2604 OID 16621)
-- Name: yazar No; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yazar ALTER COLUMN "No" SET DEFAULT nextval('public."yazar_No_seq"'::regclass);


--
-- TOC entry 3502 (class 0 OID 16594)
-- Dependencies: 215
-- Data for Name: adres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adres ("adresNo", "ilNo", kisi_id, "ilceNo", "mahalleNo", "sokakNo") FROM stdin;
58	1	113	1	1	2
59	1	114	1	1	2
34	1	76	1	1	10
\.


--
-- TOC entry 3514 (class 0 OID 16859)
-- Dependencies: 227
-- Data for Name: fatura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fatura ("NO", "FaturaTarihi", "Topalm", "islemNo") FROM stdin;
\.


--
-- TOC entry 3525 (class 0 OID 17701)
-- Dependencies: 238
-- Data for Name: il; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.il ("ilNo", "ilAdi") FROM stdin;
1	SAKARYA
\.


--
-- TOC entry 3527 (class 0 OID 17708)
-- Dependencies: 240
-- Data for Name: ilce; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ilce ("ilceNo", "ilceAdi", "ilNO") FROM stdin;
1	SERDIVAN	1
\.


--
-- TOC entry 3512 (class 0 OID 16842)
-- Dependencies: 225
-- Data for Name: ilet_b; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ilet_b ("iletNO", "TelNO", adresid, "kisiId", "EmailAD") FROM stdin;
34	2153435	34	76	J@GMAIL.COM
53	153454	58	113	
54	44545	59	114	
\.


--
-- TOC entry 3508 (class 0 OID 16806)
-- Dependencies: 221
-- Data for Name: kisi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kisi ("KNo", "kisiId", adi, soyadi, "Uye", "Personel") FROM stdin;
76	1212121	jamal	ALI	H	E
114	4545	amir	AMIR	E	H
113	645	saed	JAMAL	H	E
\.


--
-- TOC entry 3519 (class 0 OID 16876)
-- Dependencies: 232
-- Data for Name: kit_ad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kit_ad ("KOD", "KAT", kit_id, raf) FROM stdin;
1	1	1	1
\.


--
-- TOC entry 3516 (class 0 OID 16867)
-- Dependencies: 229
-- Data for Name: kitap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitap (id, adi, yazarid, "yayinevi_ID", tur, "stockSayisi", "O_AL_S") FROM stdin;
1	ELMA	1	1	KOMIK	5	0
5	VTYS	1	1	BMG	5	0
6	matematik	1	1	bilimsel	5	0
7	VERIYAPILARI	1	1	bilemsel	5	0
4	ASK	1	1	ROMANTIK	5	0
9	kimya	1	1	bilemsel	5	0
\.


--
-- TOC entry 3523 (class 0 OID 17052)
-- Dependencies: 236
-- Data for Name: kutuphane; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kutuphane ("NO", adi, "SorumluId", "Uye_Sayisi", "kitap_Sayisi", "Personel_Sayisi") FROM stdin;
2	MARKEZI KUTUPHANE	76	1	6	2
\.


--
-- TOC entry 3529 (class 0 OID 17720)
-- Dependencies: 242
-- Data for Name: mahalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mahalle ("mahalleNo", "mahalleAdi", "ilceNo") FROM stdin;
1	kemalpasa	1
2	Arabac?alan?	1
3	Kazimpasa	1
\.


--
-- TOC entry 3521 (class 0 OID 16907)
-- Dependencies: 234
-- Data for Name: odunc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.odunc ("islemNo", "UyeId", "OD_Al_kit_ID", "Tur", "PersonelID") FROM stdin;
\.


--
-- TOC entry 3509 (class 0 OID 16814)
-- Dependencies: 222
-- Data for Name: personel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personel ("PNo", "Ucreti") FROM stdin;
76	5000
113	5000
\.


--
-- TOC entry 3533 (class 0 OID 17781)
-- Dependencies: 246
-- Data for Name: sil_kisi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sil_kisi ("NO", kutuphaneid, id, adi, "Soyadi", tur, "SilmeTarihi") FROM stdin;
1	2	1212	jamal	ALI	Uye	2022-12-15
2	2	1212	jamal	ALI	Uye	2022-12-15
6	2	12354	amera	ALI	Uye	2022-12-15
7	2	12354444	amer	BASEET	Uye	2022-12-15
8	2	154451	amir	BASEET	Uye	2022-12-15
9	2	12354	amera	ALI	Uye	2022-12-16
10	2	11111	ali	YAMAN	Uye	2022-12-16
11	2	55645	ali	YAMAN	Uye	2022-12-16
12	2	1545687	ali	YAMAN	Uye	2022-12-16
13	2	15478	ali	YAMAN	Uye	2022-12-16
14	2	1023544	ali	YAMAN	Uye	2022-12-16
15	2	1546564	eid	JAMAL	Uye	2022-12-16
16	2	15456878	ali	YAMAN	Uye	2022-12-16
18	2	564645	amira	MOHMAMAD	Uye	2022-12-16
19	2	12313212	samer	SAED	Uye	2022-12-16
20	2	16456	samera	EID	Uye	2022-12-16
21	2	1645648	sami	EID	Uye	2022-12-16
22	2	1215	abdulrahman	ALI	Uye	2022-12-16
23	2	1212	jamal	ALI	Uye	2022-12-16
24	2	1235465	alaa	MASRI	Uye	2022-12-16
25	2	65465	ali	YAMAN	Uye	2022-12-16
26	2	4545	amir	AMIR	Uye	2022-12-16
27	2	645	ali	ALI	Uye	2022-12-16
28	2	45645	issa	ALI	Uye	2022-12-17
\.


--
-- TOC entry 3531 (class 0 OID 17732)
-- Dependencies: 244
-- Data for Name: sokak; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sokak ("No", "mahalleNo") FROM stdin;
2	1
3	1
4	1
5	1
6	1
7	1
8	1
9	1
10	1
11	1
12	1
13	1
14	1
15	1
16	1
17	1
18	1
19	1
20	1
21	1
22	2
23	2
24	2
25	2
26	2
27	2
28	2
29	2
30	2
31	2
32	2
33	2
34	2
35	2
36	2
37	2
38	2
39	2
40	2
41	2
42	2
43	2
44	2
45	2
46	2
47	2
48	2
49	2
50	2
51	3
52	3
53	3
54	3
55	3
56	3
57	3
58	3
59	3
60	3
61	3
62	3
63	3
64	3
65	3
66	3
67	3
68	3
69	3
70	3
71	3
72	3
73	3
74	2
75	2
76	2
77	2
\.


--
-- TOC entry 3510 (class 0 OID 16819)
-- Dependencies: 223
-- Data for Name: uye; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uye ("UNo", "Kayittarihi", "OD_Al_kit_S") FROM stdin;
114	2022-12-16	0
\.


--
-- TOC entry 3504 (class 0 OID 16606)
-- Dependencies: 217
-- Data for Name: yayinevi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yayinevi ("No", adi) FROM stdin;
1	BEYAZEV
\.


--
-- TOC entry 3506 (class 0 OID 16618)
-- Dependencies: 219
-- Data for Name: yazar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yazar ("No", "Adi", yas) FROM stdin;
1	ALI	55
2	CEMIL	35
\.


--
-- TOC entry 3555 (class 0 OID 0)
-- Dependencies: 214
-- Name: adres_adresNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."adres_adresNo_seq"', 60, true);


--
-- TOC entry 3556 (class 0 OID 0)
-- Dependencies: 226
-- Name: fatura_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."fatura_NO_seq"', 30, true);


--
-- TOC entry 3557 (class 0 OID 0)
-- Dependencies: 237
-- Name: il_ilNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."il_ilNo_seq"', 1, true);


--
-- TOC entry 3558 (class 0 OID 0)
-- Dependencies: 239
-- Name: ilce_ilceNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ilce_ilceNo_seq"', 3, true);


--
-- TOC entry 3559 (class 0 OID 0)
-- Dependencies: 224
-- Name: ilet_b_iletNO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ilet_b_iletNO_seq"', 55, true);


--
-- TOC entry 3560 (class 0 OID 0)
-- Dependencies: 220
-- Name: kisi_KNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kisi_KNo_seq"', 115, true);


--
-- TOC entry 3561 (class 0 OID 0)
-- Dependencies: 230
-- Name: kit_ad_KOD_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kit_ad_KOD_seq"', 1, true);


--
-- TOC entry 3562 (class 0 OID 0)
-- Dependencies: 231
-- Name: kit_ad_raf_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kit_ad_raf_seq', 1, true);


--
-- TOC entry 3563 (class 0 OID 0)
-- Dependencies: 228
-- Name: kitap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitap_id_seq', 9, true);


--
-- TOC entry 3564 (class 0 OID 0)
-- Dependencies: 235
-- Name: kutuphane_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."kutuphane_NO_seq"', 2, true);


--
-- TOC entry 3565 (class 0 OID 0)
-- Dependencies: 241
-- Name: mahalle_mahalleNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."mahalle_mahalleNo_seq"', 3, true);


--
-- TOC entry 3566 (class 0 OID 0)
-- Dependencies: 233
-- Name: odunc_islemNo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."odunc_islemNo_seq"', 33, true);


--
-- TOC entry 3567 (class 0 OID 0)
-- Dependencies: 245
-- Name: sil_kisi_NO_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."sil_kisi_NO_seq"', 28, true);


--
-- TOC entry 3568 (class 0 OID 0)
-- Dependencies: 243
-- Name: sokak_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."sokak_No_seq"', 77, true);


--
-- TOC entry 3569 (class 0 OID 0)
-- Dependencies: 216
-- Name: yayinevi_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."yayinevi_No_seq"', 1, true);


--
-- TOC entry 3570 (class 0 OID 0)
-- Dependencies: 218
-- Name: yazar_No_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."yazar_No_seq"', 2, true);


--
-- TOC entry 3313 (class 2606 OID 16865)
-- Name: fatura F_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fatura
    ADD CONSTRAINT "F_pk" PRIMARY KEY ("NO");


--
-- TOC entry 3321 (class 2606 OID 17060)
-- Name: kutuphane Kutuphane_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kutuphane
    ADD CONSTRAINT "Kutuphane_pk" PRIMARY KEY ("NO");


--
-- TOC entry 3319 (class 2606 OID 16913)
-- Name: odunc Odunc_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT "Odunc_pk" PRIMARY KEY ("islemNo");


--
-- TOC entry 3307 (class 2606 OID 16818)
-- Name: personel PersonelPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT "PersonelPK" PRIMARY KEY ("PNo");


--
-- TOC entry 3331 (class 2606 OID 17789)
-- Name: sil_kisi Sil_Kisi_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sil_kisi
    ADD CONSTRAINT "Sil_Kisi_pk" PRIMARY KEY ("NO");


--
-- TOC entry 3329 (class 2606 OID 17737)
-- Name: sokak SokakPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sokak
    ADD CONSTRAINT "SokakPK" PRIMARY KEY ("No");


--
-- TOC entry 3309 (class 2606 OID 16825)
-- Name: uye UyePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uye
    ADD CONSTRAINT "UyePK" PRIMARY KEY ("UNo");


--
-- TOC entry 3301 (class 2606 OID 16623)
-- Name: yazar YazarPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yazar
    ADD CONSTRAINT "YazarPK" PRIMARY KEY ("No");


--
-- TOC entry 3297 (class 2606 OID 16599)
-- Name: adres adresPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "adresPK" PRIMARY KEY ("adresNo");


--
-- TOC entry 3323 (class 2606 OID 17706)
-- Name: il ilPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.il
    ADD CONSTRAINT "ilPK" PRIMARY KEY ("ilNo");


--
-- TOC entry 3325 (class 2606 OID 17713)
-- Name: ilce ilcePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilce
    ADD CONSTRAINT "ilcePK" PRIMARY KEY ("ilceNo");


--
-- TOC entry 3311 (class 2606 OID 16847)
-- Name: ilet_b iletNoPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilet_b
    ADD CONSTRAINT "iletNoPK" PRIMARY KEY ("iletNO");


--
-- TOC entry 3303 (class 2606 OID 16813)
-- Name: kisi kisi_kisiId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi
    ADD CONSTRAINT "kisi_kisiId_key" UNIQUE ("kisiId");


--
-- TOC entry 3317 (class 2606 OID 16895)
-- Name: kit_ad kit_AD_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kit_ad
    ADD CONSTRAINT "kit_AD_pk" PRIMARY KEY ("KOD");


--
-- TOC entry 3315 (class 2606 OID 16893)
-- Name: kitap kitap_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT kitap_pk PRIMARY KEY (id);


--
-- TOC entry 3327 (class 2606 OID 17725)
-- Name: mahalle mahallePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mahalle
    ADD CONSTRAINT "mahallePK" PRIMARY KEY ("mahalleNo");


--
-- TOC entry 3305 (class 2606 OID 16811)
-- Name: kisi personelPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kisi
    ADD CONSTRAINT "personelPK" PRIMARY KEY ("KNo");


--
-- TOC entry 3299 (class 2606 OID 16611)
-- Name: yayinevi yayinPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yayinevi
    ADD CONSTRAINT "yayinPK" PRIMARY KEY ("No");


--
-- TOC entry 3358 (class 2620 OID 17658)
-- Name: kitap ktp_s_arttr_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER ktp_s_arttr_trggr AFTER INSERT ON public.kitap FOR EACH ROW EXECUTE FUNCTION public.ktp_s_arttr();


--
-- TOC entry 3354 (class 2620 OID 17526)
-- Name: personel per_s_arttr_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER per_s_arttr_trggr AFTER INSERT ON public.personel FOR EACH ROW EXECUTE FUNCTION public.personel_s_arttr();


--
-- TOC entry 3355 (class 2620 OID 17662)
-- Name: personel personel_sil_once_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER personel_sil_once_trggr BEFORE DELETE ON public.personel FOR EACH ROW EXECUTE FUNCTION public.personel_sil_once();


--
-- TOC entry 3356 (class 2620 OID 17532)
-- Name: uye uye_s_arttr_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER uye_s_arttr_trggr AFTER INSERT ON public.uye FOR EACH ROW EXECUTE FUNCTION public.uye_s_arttr();


--
-- TOC entry 3357 (class 2620 OID 17689)
-- Name: uye uye_sil_once_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER uye_sil_once_trggr BEFORE DELETE ON public.uye FOR EACH ROW EXECUTE FUNCTION public.uye_sil_once();


--
-- TOC entry 3353 (class 2620 OID 17693)
-- Name: kisi yazi_dzlt_trggr; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER yazi_dzlt_trggr BEFORE INSERT OR UPDATE ON public.kisi FOR EACH ROW EXECUTE FUNCTION public.yazi_dzlt();


--
-- TOC entry 3341 (class 2606 OID 17681)
-- Name: fatura F_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fatura
    ADD CONSTRAINT "F_FK" FOREIGN KEY ("islemNo") REFERENCES public.odunc("islemNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3345 (class 2606 OID 17464)
-- Name: odunc KitapID_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT "KitapID_FK" FOREIGN KEY ("OD_Al_kit_ID") REFERENCES public.kitap(id);


--
-- TOC entry 3351 (class 2606 OID 17738)
-- Name: sokak MAH_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sokak
    ADD CONSTRAINT "MAH_FK" FOREIGN KEY ("mahalleNo") REFERENCES public.mahalle("mahalleNo");


--
-- TOC entry 3337 (class 2606 OID 16826)
-- Name: personel Per_Kis_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personel
    ADD CONSTRAINT "Per_Kis_FK" FOREIGN KEY ("PNo") REFERENCES public.kisi("KNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3346 (class 2606 OID 17795)
-- Name: odunc PersonelID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT "PersonelID" FOREIGN KEY ("PersonelID") REFERENCES public.personel("PNo");


--
-- TOC entry 3348 (class 2606 OID 17061)
-- Name: kutuphane SorumluId_Pk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kutuphane
    ADD CONSTRAINT "SorumluId_Pk" FOREIGN KEY ("SorumluId") REFERENCES public.personel("PNo");


--
-- TOC entry 3347 (class 2606 OID 17454)
-- Name: odunc Uye_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.odunc
    ADD CONSTRAINT "Uye_FK" FOREIGN KEY ("UyeId") REFERENCES public.uye("UNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3338 (class 2606 OID 16831)
-- Name: uye Uye_Kis_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uye
    ADD CONSTRAINT "Uye_Kis_FK" FOREIGN KEY ("UNo") REFERENCES public.kisi("KNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3342 (class 2606 OID 16882)
-- Name: kitap YazarFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT "YazarFK" FOREIGN KEY (yazarid) REFERENCES public.yazar("No");


--
-- TOC entry 3332 (class 2606 OID 17743)
-- Name: adres ilFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "ilFK" FOREIGN KEY ("ilNo") REFERENCES public.il("ilNo");


--
-- TOC entry 3349 (class 2606 OID 17714)
-- Name: ilce ilceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilce
    ADD CONSTRAINT "ilceFK" FOREIGN KEY ("ilNO") REFERENCES public.il("ilNo");


--
-- TOC entry 3333 (class 2606 OID 17753)
-- Name: adres ilceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "ilceFK" FOREIGN KEY ("ilceNo") REFERENCES public.ilce("ilceNo");


--
-- TOC entry 3339 (class 2606 OID 17041)
-- Name: ilet_b ilet_Kis_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilet_b
    ADD CONSTRAINT "ilet_Kis_FK" FOREIGN KEY ("kisiId") REFERENCES public.kisi("KNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3340 (class 2606 OID 17449)
-- Name: ilet_b ilet_ad_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ilet_b
    ADD CONSTRAINT "ilet_ad_FK" FOREIGN KEY (adresid) REFERENCES public.adres("adresNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3334 (class 2606 OID 17009)
-- Name: adres kisi_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "kisi_id_FK" FOREIGN KEY (kisi_id) REFERENCES public.kisi("KNo") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3344 (class 2606 OID 16901)
-- Name: kit_ad kit_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kit_ad
    ADD CONSTRAINT "kit_id_FK" FOREIGN KEY (kit_id) REFERENCES public.kitap(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3352 (class 2606 OID 17790)
-- Name: sil_kisi kutuphaneid_FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sil_kisi
    ADD CONSTRAINT "kutuphaneid_FK" FOREIGN KEY (kutuphaneid) REFERENCES public.kutuphane("NO");


--
-- TOC entry 3350 (class 2606 OID 17726)
-- Name: mahalle mahalleFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mahalle
    ADD CONSTRAINT "mahalleFK" FOREIGN KEY ("ilceNo") REFERENCES public.ilce("ilceNo");


--
-- TOC entry 3335 (class 2606 OID 17758)
-- Name: adres mahalleFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "mahalleFK" FOREIGN KEY ("mahalleNo") REFERENCES public.mahalle("mahalleNo");


--
-- TOC entry 3336 (class 2606 OID 17748)
-- Name: adres sokakFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adres
    ADD CONSTRAINT "sokakFK" FOREIGN KEY ("sokakNo") REFERENCES public.sokak("No");


--
-- TOC entry 3343 (class 2606 OID 16887)
-- Name: kitap yayinFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitap
    ADD CONSTRAINT "yayinFK" FOREIGN KEY ("yayinevi_ID") REFERENCES public.yayinevi("No");


-- Completed on 2022-12-20 16:00:18

--
-- PostgreSQL database dump complete
--

