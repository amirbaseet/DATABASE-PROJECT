﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class UyeEkSil : Form
    {
        public UyeEkSil()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();

            dataGridView1.AutoResizeRows();//sütuna sığdırmak için
            dataGridView1.AutoResizeColumns();
            this.dataGridView1.AutoSize = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UyeEklecs uyeEklecs = new UyeEklecs();
            uyeEklecs.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UyeSil uyeSil =new UyeSil();
            uyeSil.ShowDialog();   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            VarPUyeEkle varPUyeEkle = new VarPUyeEkle();
            varPUyeEkle.ShowDialog();
        }

        private void UyeEkSil_Load(object sender, EventArgs e)
        {
            Select();
        }
       

        private void UyeEkSil_Activated(object sender, EventArgs e)
        {
            Select();
        }
        private void Select()
        {
            string command = "select * from kisi RIGHT JOIN Uye ON kisi.\"KNo\" =Uye.\"UNo\"";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(command, Global.connection);

            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];


        }
    }
}
