﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class yeniPer_ekle : Form
    {
      

        public yeniPer_ekle()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Global.Y_Per_ekle(int.Parse(KID.Text), adi.Text, soyadi.Text, int.Parse(Ucreti.Text), int.Parse(il.Text),
                int.Parse(ilce.Text), int.Parse(mahalle.Text), int.Parse(sokak.Text), int.Parse(tel.Text), EmailAD.Text);
           
        }
    }
}
