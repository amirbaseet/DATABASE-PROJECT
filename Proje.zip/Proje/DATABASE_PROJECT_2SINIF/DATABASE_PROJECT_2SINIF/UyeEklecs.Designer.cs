﻿namespace DATABASE_PROJECT_2SINIF
{
    partial class UyeEklecs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.EmailAD = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tel = new System.Windows.Forms.TextBox();
            this.ilce = new System.Windows.Forms.TextBox();
            this.sokak = new System.Windows.Forms.TextBox();
            this.il = new System.Windows.Forms.TextBox();
            this.mahalle = new System.Windows.Forms.TextBox();
            this.soyadi = new System.Windows.Forms.TextBox();
            this.adi = new System.Windows.Forms.TextBox();
            this.kisiID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(431, 276);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 17);
            this.label10.TabIndex = 40;
            this.label10.Text = "Email AD";
            // 
            // EmailAD
            // 
            this.EmailAD.Location = new System.Drawing.Point(512, 269);
            this.EmailAD.Name = "EmailAD";
            this.EmailAD.Size = new System.Drawing.Size(100, 24);
            this.EmailAD.TabIndex = 39;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(296, 341);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 71);
            this.button1.TabIndex = 38;
            this.button1.Text = "EKLE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(431, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 17);
            this.label9.TabIndex = 37;
            this.label9.Text = "TEL NO";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(431, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 36;
            this.label8.Text = "sokak No";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(431, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 17);
            this.label7.TabIndex = 35;
            this.label7.Text = "Mahalle NO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(431, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 17);
            this.label6.TabIndex = 34;
            this.label6.Text = "ilce No";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(77, 218);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 17);
            this.label5.TabIndex = 33;
            this.label5.Text = "il No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "soyadi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 17);
            this.label2.TabIndex = 30;
            this.label2.Text = "adi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 29;
            this.label1.Text = "kisiID";
            // 
            // tel
            // 
            this.tel.Location = new System.Drawing.Point(512, 204);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(100, 24);
            this.tel.TabIndex = 28;
            // 
            // ilce
            // 
            this.ilce.Location = new System.Drawing.Point(512, 54);
            this.ilce.Name = "ilce";
            this.ilce.Size = new System.Drawing.Size(100, 24);
            this.ilce.TabIndex = 25;
            // 
            // sokak
            // 
            this.sokak.Location = new System.Drawing.Point(512, 156);
            this.sokak.Name = "sokak";
            this.sokak.Size = new System.Drawing.Size(100, 24);
            this.sokak.TabIndex = 27;
            // 
            // il
            // 
            this.il.Location = new System.Drawing.Point(211, 211);
            this.il.Name = "il";
            this.il.Size = new System.Drawing.Size(100, 24);
            this.il.TabIndex = 24;
            // 
            // mahalle
            // 
            this.mahalle.Location = new System.Drawing.Point(512, 105);
            this.mahalle.Name = "mahalle";
            this.mahalle.Size = new System.Drawing.Size(100, 24);
            this.mahalle.TabIndex = 26;
            // 
            // soyadi
            // 
            this.soyadi.Location = new System.Drawing.Point(211, 152);
            this.soyadi.Name = "soyadi";
            this.soyadi.Size = new System.Drawing.Size(100, 24);
            this.soyadi.TabIndex = 22;
            // 
            // adi
            // 
            this.adi.Location = new System.Drawing.Point(211, 105);
            this.adi.Name = "adi";
            this.adi.Size = new System.Drawing.Size(100, 24);
            this.adi.TabIndex = 21;
            // 
            // kisiID
            // 
            this.kisiID.Location = new System.Drawing.Point(211, 54);
            this.kisiID.Name = "kisiID";
            this.kisiID.Size = new System.Drawing.Size(100, 24);
            this.kisiID.TabIndex = 20;
            // 
            // UyeEklecs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.EmailAD);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tel);
            this.Controls.Add(this.ilce);
            this.Controls.Add(this.sokak);
            this.Controls.Add(this.il);
            this.Controls.Add(this.mahalle);
            this.Controls.Add(this.soyadi);
            this.Controls.Add(this.adi);
            this.Controls.Add(this.kisiID);
            this.Name = "UyeEklecs";
            this.Text = "UyeEklecs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox EmailAD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tel;
        private System.Windows.Forms.TextBox ilce;
        private System.Windows.Forms.TextBox sokak;
        private System.Windows.Forms.TextBox il;
        private System.Windows.Forms.TextBox mahalle;
        private System.Windows.Forms.TextBox soyadi;
        private System.Windows.Forms.TextBox adi;
        private System.Windows.Forms.TextBox kisiID;
    }
}