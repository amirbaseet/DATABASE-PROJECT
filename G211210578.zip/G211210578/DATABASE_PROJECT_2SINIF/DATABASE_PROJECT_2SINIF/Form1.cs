﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{

    public partial class Form1 : Form
    {

        public Form1()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum
           
            InitializeComponent();
            dgvData.AutoResizeRows();//sütuna sığdırmak için
            dgvData.AutoResizeColumns();
            this.dgvData.AutoSize = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Select();
        }
        private void Select() 
        {
            string command = "select * from kutuphane";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(command,Global.connection);

            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvData.DataSource = ds.Tables[0];


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sorumlu sorumlu = new Sorumlu();
            sorumlu.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            personel personel =new personel();
            personel.ShowDialog();
        }
    }
}
