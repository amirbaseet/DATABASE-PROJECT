﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DATABASE_PROJECT_2SINIF
{
    public partial class personel : Form
    {
        public personel()
        {
            this.StartPosition = FormStartPosition.CenterScreen;//form ekran ortasinda baslasin
            this.FormBorderStyle = FormBorderStyle.FixedSingle;//form buytme ve kucutme önler
            this.MaximizeBox = false;//form buytme engellir
            this.BackColor = Color.SlateGray;//formun rengi degistiriyorum

            InitializeComponent();
        }

        private void personel_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UyeEkSil uyeEkSil = new UyeEkSil();
            uyeEkSil.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OduncVer oduncVer =new OduncVer();
            oduncVer.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Iade iade =new Iade();
            iade.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ktpekle ktpekle = new ktpekle();
            ktpekle.ShowDialog();   
        }
    }
}
